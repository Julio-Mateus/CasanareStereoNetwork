package com.jcmateus.casanarestereo.screens.home


import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
//noinspection UsingMaterialAndMaterial3Libraries
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.Scaffold
import androidx.compose.material.ScaffoldState
import androidx.compose.material.Text
import androidx.compose.material.TextButton
import androidx.compose.material.TopAppBar
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.rememberScaffoldState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.jcmateus.casanarestereo.HomeApplication
import com.jcmateus.casanarestereo.R
import com.jcmateus.casanarestereo.navigation.RouteAccess
import com.jcmateus.casanarestereo.navigation.RouteAccessManager
import com.jcmateus.casanarestereo.screens.formulario.PantallaFormulario
import com.jcmateus.casanarestereo.screens.login.AuthService
import com.jcmateus.casanarestereo.screens.login.DataStoreManager
import com.jcmateus.casanarestereo.screens.login.LoginScreenViewModel
import com.jcmateus.casanarestereo.screens.login.LoginScreenViewModelFactory
import com.jcmateus.casanarestereo.screens.login.Rol
import com.jcmateus.casanarestereo.screens.menus.CerrarSesionButton
import com.jcmateus.casanarestereo.screens.menus.Clasificados
import com.jcmateus.casanarestereo.screens.menus.configuracion.Configuraciones
import com.jcmateus.casanarestereo.screens.menus.Contactenos
import com.jcmateus.casanarestereo.screens.menus.Inicio
import com.jcmateus.casanarestereo.screens.menus.Mi_Zona
import com.jcmateus.casanarestereo.screens.menus.Noticias_Internacionales
import com.jcmateus.casanarestereo.screens.menus.Noticias_Nacionales
import com.jcmateus.casanarestereo.screens.menus.Noticias_Regionales
import com.jcmateus.casanarestereo.screens.menus.Podcast
import com.jcmateus.casanarestereo.screens.menus.Programacion
import com.jcmateus.casanarestereo.screens.menus.Programas
import com.jcmateus.casanarestereo.screens.menus.Se_Le_Tiene
import com.jcmateus.casanarestereo.screens.menus.VideosYoutubeView
import com.jcmateus.casanarestereo.screens.menus.Youtube_Casanare
import com.jcmateus.casanarestereo.screens.menus.emisoras.EmisorasScreen
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.EmisoraViewModel
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.EmisoraVista
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.FormularioPerfilEmisora
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.noticias.FormularioNoticia
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.noticias.VistaNoticia
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.podcast.FormularioPodcast
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.podcast.PodcastViewModel
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.podcast.VistaPodcast
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.programacion.FormularioPrograma
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.programacion.VistaPrograma
import com.jcmateus.casanarestereo.screens.usuarios.usuario.UsuarioPerfilScreen
import com.jcmateus.casanarestereo.screens.usuarios.usuario.UsuarioPerfilViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlin.text.contains

//import kotlinx.coroutines.flow.internal.NoOpContinuation.context
//import kotlin.coroutines.jvm.internal.CompletedContinuation.context

// Función para determinar si se debe mostrar la barra inferior
fun shouldShowBottomBar(currentRoute: String, userRol: Rol?): Boolean {
    Log.d("shouldShowBottomBar", "currentRoute: $currentRoute, userRol: $userRol")
    if (userRol == null) return false
    return when (userRol) {
        Rol.USUARIO -> currentRoute in RouteAccessManager.usuarioBottomBarRoutes
        Rol.EMISORA -> currentRoute in RouteAccessManager.emisoraBottomBarRoutes
        Rol.ADMINISTRADOR -> currentRoute in RouteAccessManager.usuarioBottomBarRoutes
        else -> false
    }
}

// Función para determinar si se debe mostrar la barra superior
fun shouldShowTopBar(currentRoute: String, userRol: Rol?): Boolean {
    if (userRol == null) return false
    return when (userRol) {
        Rol.USUARIO -> currentRoute !in RouteAccessManager.excludedRoutes
        Rol.EMISORA -> currentRoute !in RouteAccessManager.excludedRoutes
        Rol.ADMINISTRADOR -> currentRoute !in RouteAccessManager.excludedRoutes
        else -> false
    }
}

// Función para determinar si se debe mostrar el cajón de navegación
fun shouldShowDrawer(currentRoute: String, userRol: Rol?): Boolean {
    if (userRol == null) return false
    return when (userRol) {
        Rol.USUARIO -> currentRoute !in RouteAccessManager.excludedRoutes
        Rol.EMISORA -> currentRoute !in RouteAccessManager.excludedRoutes
        Rol.ADMINISTRADOR -> currentRoute !in RouteAccessManager.excludedRoutes
        else -> false
    }
}

// Función para obtener los destinos de la barra inferior según el rol
fun getBottomNavDestinations(userRol: Rol?): List<Destinos> {
    if (userRol == null) return emptyList()
    return RouteAccessManager.routeAccessList
        .filter { RouteAccessManager.isRouteAccessible(it.route, userRol) }
        .filter {
            when (userRol) {
                Rol.USUARIO -> it.route in RouteAccessManager.usuarioBottomBarRoutes
                Rol.EMISORA -> it.route in RouteAccessManager.emisoraBottomBarRoutes
                Rol.ADMINISTRADOR -> it.route in RouteAccessManager.usuarioBottomBarRoutes
                else -> false
            }
        }
        .map {
            when (it.route) {
                Destinos.Pantalla1.ruta -> Destinos.Pantalla1
                Destinos.Pantalla2.ruta -> Destinos.Pantalla2
                Destinos.Pantalla8.ruta -> Destinos.Pantalla8
                Destinos.VistaNoticia().ruta -> Destinos.VistaNoticia()
                Destinos.VistaPodcast().ruta -> Destinos.VistaPodcast()
                Destinos.VistaPrograma.ruta -> Destinos.VistaPrograma
                else -> Destinos.Pantalla1
            }
        }
        .distinct()
}

// Función para envolver las pantallas con el Scaffold
@Composable
fun ScaffoldWithNavigation(
    userRol: Rol?,
    currentRoute: String,
    navController: NavHostController,
    dataStoreManager: DataStoreManager,
    authService: AuthService,
    content: @Composable (PaddingValues) -> Unit
) {
    val scope = rememberCoroutineScope()
    val scaffoldState = rememberScaffoldState()
    val allDestinations = remember(userRol) {
        if (userRol != null) {
            RouteAccessManager.routeAccessList
                .filter { RouteAccessManager.isRouteAccessible(it.route, userRol) }
                .map {
                    when (it.route) {
                        Destinos.Pantalla1.ruta -> Destinos.Pantalla1
                        Destinos.Pantalla2.ruta -> Destinos.Pantalla2
                        Destinos.Pantalla3.ruta -> Destinos.Pantalla3
                        Destinos.Pantalla4.ruta -> Destinos.Pantalla4
                        Destinos.Pantalla5.ruta -> Destinos.Pantalla5
                        Destinos.Pantalla6.ruta -> Destinos.Pantalla6
                        Destinos.Pantalla7.ruta -> Destinos.Pantalla7
                        Destinos.Pantalla8.ruta -> Destinos.Pantalla8
                        Destinos.Pantalla9.ruta -> Destinos.Pantalla9
                        Destinos.Pantalla10.ruta -> Destinos.Pantalla10
                        Destinos.Pantalla11.ruta -> Destinos.Pantalla11
                        Destinos.Pantalla12.ruta -> Destinos.Pantalla12
                        Destinos.Pantalla13.ruta -> Destinos.Pantalla13
                        Destinos.Pantalla17.ruta -> Destinos.Pantalla17
                        Destinos.AcercaDe.ruta -> Destinos.AcercaDe
                        Destinos.Notificaciones.ruta -> Destinos.Notificaciones
                        Destinos.Privacidad.ruta -> Destinos.Privacidad
                        Destinos.Tema.ruta -> Destinos.Tema
                        Destinos.EmisoraVista.ruta -> Destinos.EmisoraVista
                        Destinos.FormularioPerfilEmisora.ruta -> Destinos.FormularioPerfilEmisora
                        Destinos.FormularioNoticia.ruta -> Destinos.FormularioNoticia
                        Destinos.FormularioPodcast.ruta -> Destinos.FormularioPodcast
                        Destinos.FormularioPrograma.ruta -> Destinos.FormularioPrograma
                        Destinos.UsuarioPerfilScreen.ruta -> Destinos.UsuarioPerfilScreen
                        Destinos.VistaNoticia().ruta -> Destinos.VistaNoticia()
                        Destinos.VistaPodcast().ruta -> Destinos.VistaPodcast()
                        Destinos.VistaPrograma.ruta -> Destinos.VistaPrograma
                        else -> Destinos.Pantalla1
                    }
                }
        } else {
            emptyList()
        }
    }
    var expanded by remember { mutableStateOf(false) }
    if (shouldShowTopBar(currentRoute, userRol) || shouldShowBottomBar(currentRoute, userRol) || shouldShowDrawer(currentRoute, userRol)) {
        Scaffold(
            scaffoldState = scaffoldState,
            topBar = {
                if (shouldShowTopBar(currentRoute, userRol)) {
                    TopBar(
                        scope = scope,
                        scaffoldState = scaffoldState,
                        navController = navController,
                        items = allDestinations,
                        userRol = userRol
                    )
                }
            },
            bottomBar = {
                if (shouldShowBottomBar(currentRoute, userRol)) {
                    NavegacionInferior(
                        navController = navController,
                        items = getBottomNavDestinations(userRol),
                        expanded = expanded,
                        onExpandedChange = { expanded = it },
                        innerPadding = PaddingValues(0.dp),
                        dataStoreManager = dataStoreManager,
                        authService = authService,
                        userRol = userRol
                    )
                }
            },
            drawerContent = {
                if (shouldShowDrawer(currentRoute, userRol)) {
                    Drawer(
                        scope = scope,
                        scaffoldState = scaffoldState,
                        navController = navController,
                        items = allDestinations,
                        userRol = userRol
                    )
                }
            }
        ) { innerPadding ->
            content(innerPadding)
        }
    } else {
        content(PaddingValues(0.dp))
    }
}

// Composable para el cajón de navegación (Drawer)
@Composable
fun Drawer(
    scope: CoroutineScope,
    scaffoldState: ScaffoldState,
    navController: NavHostController,
    items: List<Destinos>,
    userRol: Rol?
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                items.forEach { item ->
                    if (RouteAccessManager.isRouteAccessible(item.ruta, userRol)) {
                        NavigationDrawerItem(
                            label = { Text(text = item.title) },
                            selected = false,
                            onClick = {
                                scope.launch {
                                    drawerState.close()
                                }
                                navController.navigate(item.ruta) {
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            modifier = Modifier.background(Color.LightGray)
                        )
                    }
                }
            }
        },
        content = {

        }
    )
}
@Composable
fun NavegacionInferior(
    navController: NavHostController,
    items: List<Destinos>,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    innerPadding: PaddingValues,
    dataStoreManager: DataStoreManager,
    authService: AuthService,
    userRol: Rol?,
) {
    var cerrarSesion by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    NavigationBar(
        modifier = Modifier.fillMaxWidth(),
        containerColor = Color.LightGray
    ) {
        val currentRoute = currentRoute(navController = navController) ?: ""
        items.forEach { item ->
            if (RouteAccessManager.isRouteAccessible(item.ruta, userRol)) {
                NavigationBarItem(
                    selected = currentRoute == item.ruta,
                    onClick = {
                        navController.navigate(item.ruta) {
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    icon = {
                        item.icon?.let {
                            Icon(
                                painter = painterResource(id = item.icon),
                                contentDescription = item.title,
                                tint = Color.Black,
                                modifier = Modifier
                                    .size(25.dp)
                                    .shadow(
                                        elevation = 10.dp,
                                        shape = CircleShape,
                                        clip = true
                                    )
                            )
                        }
                    },
                    label = {
                        Text(item.title)
                    },
                    alwaysShowLabel = false
                )
            }
        }
        IconButton(onClick = { onExpandedChange(true) }) {
            androidx.compose.material3.Icon(Icons.Filled.MoreVert, contentDescription = "Menú")
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { onExpandedChange(false) },
            modifier = Modifier
                .background(MaterialTheme.colorScheme.surface)
                .offset(y = (-16).dp)
        ) {
            DropdownMenuItem(
                text = {
                    androidx.compose.material3.Text(
                        "Perfil",
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                onClick = {
                    val rutaPerfil = when (userRol) {
                        Rol.EMISORA -> Destinos.EmisoraVista.ruta
                        Rol.USUARIO -> Destinos.UsuarioPerfilScreen.ruta
                        else -> Destinos.EmisoraVista.ruta
                    }
                    navController.navigate(rutaPerfil)
                    onExpandedChange(false)
                }
            )
            DropdownMenuItem(
                text = { Text("Configuraciones", color = MaterialTheme.colorScheme.onSurface) },
                onClick = {
                    navController.navigate(Destinos.Pantalla12.ruta)
                    onExpandedChange(false)
                }
            )
            DropdownMenuItem(
                text = { Text("Cerrar Sesion", color = MaterialTheme.colorScheme.onSurface) },
                onClick = {
                    scope.launch {
                        cerrarSesion = true
                        onExpandedChange(false)
                        authService.cerrarSesion()
                        navController.navigate(Destinos.CasanareLoginScreen.ruta) {
                            popUpTo(navController.graph.startDestinationId) {
                                inclusive = true
                            }
                        }
                    }
                }
            )
        }
    }
    cerrarSesion = false
}

@Composable
fun TopBar(
    scope: CoroutineScope,
    scaffoldState: ScaffoldState,
    navController: NavHostController,
    items: List<Destinos>,
    userRol: Rol?
) {
    val viewModel: HomeViewModel = androidx.lifecycle.viewmodel.compose.viewModel()

    TopAppBar(
        backgroundColor = Color(0xFF000000).copy(alpha = 0.5f),
        contentColor = Color.Black,
        modifier = Modifier,
        title = {
            Text(
                text = viewModel.currentTitle,
                fontSize = MaterialTheme.typography.headlineSmall.fontSize,
                color = Color.White
            )
        },
        navigationIcon = {
            IconButton(onClick = {
                scope.launch {
                    scaffoldState.drawerState.open()
                }
            }) {
                Icon(Icons.Filled.Menu, contentDescription = "Menú", tint = Color.White)
            }
        }
    )
}

@Composable
fun currentRoute(navController: NavHostController): String? {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    return navBackStackEntry?.destination?.route
}



