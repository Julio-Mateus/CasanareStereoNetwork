package com.jcmateus.casanarestereo.screens.usuarios.usuario

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

@Composable
fun UsuarioVisualizarPerfilScreen(viewModel: UsuarioViewModel, navController: NavHostController, uid: String, innerPadding: PaddingValues = PaddingValues()) {
    // Estados del ViewModel
    val usuario by viewModel.usuario.collectAsState()
    val estaCargando by viewModel.isLoading.collectAsState()
    val error by viewModel.errorMessage.collectAsState()

    // Efecto para cargar el usuario al iniciar la pantalla
    LaunchedEffect(key1 = uid) {
        viewModel.getUsuario(uid)
    }

    // Contenido de la pantalla
    PerfilVisualizarContent(
        estaCargando = estaCargando,
        innerPadding = innerPadding,
        error = error,
        usuario = usuario,
        navController = navController
    )
}

@Composable
fun PerfilVisualizarContent(
    estaCargando: Boolean,
    innerPadding: PaddingValues,
    error: String?,
    usuario: Usuario?,
    navController: NavHostController
) {
    if (estaCargando) {
        CargandoContent(innerPadding)
    } else {
        PerfilVisualizarListContent(
            innerPadding = innerPadding,
            error = error,
            usuario = usuario,
            navController = navController
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerfilVisualizarTopAppBar(navController: NavHostController) {
    PerfilTopAppBar(navController = navController)
}

@Composable
fun PerfilVisualizarListContent(
    innerPadding: PaddingValues,
    error: String?,
    usuario: Usuario?,
    navController: NavHostController
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            ImagenDePerfil(
                fotoUri = null,
                avatarUrl = usuario?.avatarUrl,
                alHacerClickEnImagen = {}
            )
        }

        item {
            MostrarError(error)
        }

        item {
            Text(text = usuario?.nombre ?: "", style = MaterialTheme.typography.headlineSmall)
        }
        item {
            Text(text = "Frase: ${usuario?.frase ?: ""}")
        }
        item {
            Text(text = "Profesión: ${usuario?.profesion ?: ""}")
        }
        item {
            Text(text = "Ciudad: ${usuario?.ciudad ?: ""}")
        }
        item {
            Text(text = "Departamento: ${usuario?.departamento ?: ""}")
        }

        item {
            Text(text = "Emisoras Favoritas", fontWeight = FontWeight.Bold)
        }
        // Usar la lista de emisoras favoritas que ya hemos cargado
        if (usuario != null) {
            items(usuario.emisorasFavoritas) { emisoraId ->
                // Aquí necesitas obtener la información de la emisora a partir del ID
                // Puedes usar un repositorio o un ViewModel para esto
                // Por ahora, solo mostramos el ID
                Text(text = "Emisora ID: $emisoraId")
            }
        }
    }
}