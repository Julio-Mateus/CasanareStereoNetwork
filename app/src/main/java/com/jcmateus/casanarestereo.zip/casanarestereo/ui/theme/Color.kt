package com.jcmateus.casanarestereo.ui.theme

import androidx.compose.ui.graphics.Color
/*
val Principal: Rojo oscuro (#B71C1C)
val Secundario: Dorado (#FFD600)
val Acento: Blanco (#FFFFFF)
val Neutros: Negro (#000000), Gris oscuro (#212121)*/

val Color1 = Color(0xCCFFFB0F0F)
val Color2 = Color(0xCCFFBBBBBB)
val Color3 = Color(0xCCFFBE0002)
val Color4 = Color(0xCCFFF9F8F8)
val Color5 = Color(0xCCFFD9D9D9)
val Color6 = Color(0xCCFFF9F8F8)
val Color7 = Color(0xCCFF000000)

