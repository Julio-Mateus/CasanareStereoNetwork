package com.jcmateus.casanarestereo.screens.login


import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException
import kotlin.collections.remove
import kotlin.text.get
import kotlin.text.set
import kotlin.toString


// Define the DataStore as a top-level extension function
val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

class DataStoreManager(private val context: Context) {

    companion object {
        private const val TAG = "DataStoreManager"
        val IS_LOGGED_IN = booleanPreferencesKey("is_logged_in")
        val LOCATION_PERMISSION_GRANTED = booleanPreferencesKey("location_permission_granted")
        val SHOW_DIALOG = booleanPreferencesKey("show_dialog")
        val ROL = stringPreferencesKey("rol") // Clave más genérica
        val TERMS_ACCEPTED = booleanPreferencesKey("terms_accepted")
        val HAS_SHOWN_PRESENTATION = booleanPreferencesKey("has_shown_presentation")
        val HAS_COMPLETED_FORM = booleanPreferencesKey("has_completed_form")
        val IS_CREATING_ACCOUNT = booleanPreferencesKey("is_creating_account")
        val IS_FIRST_TIME_APP_OPEN = booleanPreferencesKey("is_first_time_app_open")
        val USER_ID = stringPreferencesKey("user_id")
        val EMISORA_ID = stringPreferencesKey("emisora_id")
    }

    suspend fun saveUserId(userId: String) {
        context.dataStore.edit { preferences ->
            preferences[USER_ID] = userId
        }
    }

    fun getUserId(): Flow<String?> = context.dataStore.data
        .handleDataStoreError()
        .map { preferences ->
            preferences[USER_ID]
        }

    suspend fun saveEmisoraId(emisoraId: String) {
        context.dataStore.edit { preferences ->
            preferences[EMISORA_ID] = emisoraId
        }
    }

    fun getEmisoraId(): Flow<String?> = context.dataStore.data
        .handleDataStoreError()
        .map { preferences ->
            preferences[EMISORA_ID]
        }

    fun getIsCreatingAccount(): Flow<Boolean> = context.dataStore.data
        .handleDataStoreError()
        .map { preferences ->
            preferences[IS_CREATING_ACCOUNT] ?: false
        }

    suspend fun saveIsCreatingAccount(value: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[IS_CREATING_ACCOUNT] = value
        }
    }

    suspend fun clearRol() {
        context.dataStore.edit { preferences ->
            preferences.remove(ROL)
        }
    }

    suspend fun clearIsLoggedIn() {
        context.dataStore.edit { preferences ->
            preferences.remove(IS_LOGGED_IN)
        }
    }

    fun isFirstTimeAppOpen(): Flow<Boolean> = context.dataStore.data
        .map { preferences ->
            !(preferences[TERMS_ACCEPTED] ?: false)
        }

    suspend fun saveAppOpened() {
        saveTermsAccepted(true)
        savePresentationShown()
    }

    fun getTermsAccepted(): Flow<Boolean> = context.dataStore.data
        .map { preferences ->
            preferences[TERMS_ACCEPTED] ?: false
        }

    suspend fun saveTermsAccepted(accepted: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[TERMS_ACCEPTED] = accepted
        }
    }

    suspend fun savePresentationShown() {
        context.dataStore.edit { preferences ->
            preferences[HAS_SHOWN_PRESENTATION] = true
        }
    }

    fun getHasShownPresentation(): Flow<Boolean> = context.dataStore.data
        .map { preferences ->
            preferences[HAS_SHOWN_PRESENTATION] ?: false
        }

    suspend fun saveRol(rol: Rol) {
        context.dataStore.edit { preferences ->
            preferences[ROL] = rol.name
        }
    }

    fun getRol(): Flow<Rol?> = context.dataStore.data
        .handleDataStoreError()
        .map { preferences ->
            val rolString = preferences[ROL]
            if (rolString == null) {
                Log.d(TAG, "No se encontró el rol en DataStore")
                null
            } else {
                try {
                    Rol.valueOf(rolString)
                } catch (e: IllegalArgumentException) {
                    Log.e(TAG, "Error al convertir el rol: $rolString", e)
                    null
                }
            }
        }

    suspend fun saveIsLoggedIn(isLoggedIn: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[IS_LOGGED_IN] = isLoggedIn
        }
    }

    fun getIsLoggedIn(): Flow<Boolean> = context.dataStore.data
        .handleDataStoreError()
        .map { preferences ->
            preferences[IS_LOGGED_IN] ?: false
        }

    suspend fun setLocationPermissionGranted(value: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[LOCATION_PERMISSION_GRANTED] = value
        }
    }

    fun getLocationPermissionGranted(): Flow<Boolean> = context.dataStore.data
        .handleDataStoreError()
        .map { preferences ->
            preferences[LOCATION_PERMISSION_GRANTED] ?: false
        }

    suspend fun setShowDialog(value: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[SHOW_DIALOG] = value
        }
    }

    fun getShowDialog(): Flow<Boolean> = context.dataStore.data
        .handleDataStoreError()
        .map { preferences ->
            preferences[SHOW_DIALOG] ?: true
        }

    suspend fun saveHasCompletedForm(value: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[HAS_COMPLETED_FORM] = value
        }
    }

    fun getHasCompletedForm(): Flow<Boolean> = context.dataStore.data
        .handleDataStoreError()
        .map { preferences ->
            preferences[HAS_COMPLETED_FORM] ?: false
        }

    fun getIsFirstTimeAppOpen(): Flow<Boolean> = context.dataStore.data
        .handleDataStoreError()
        .map { preferences ->
            preferences[IS_FIRST_TIME_APP_OPEN] ?: true
        }

    suspend fun setIsFirstTimeAppOpen(value: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[IS_FIRST_TIME_APP_OPEN] = value
        }
    }

    private fun <T> Flow<T>.handleDataStoreError(): Flow<T> =
        catch { e ->
            if (e is IOException) {
                Log.e(TAG, "Error de IO al leer desde DataStore: ${e.message}")
                emit(emptyPreferences() as T)
            } else {
                Log.e(TAG, "Error inesperado al leer desde DataStore: ${e.message}", e)
                throw e
            }
        }
}