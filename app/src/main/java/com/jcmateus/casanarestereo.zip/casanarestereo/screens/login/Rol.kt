package com.jcmateus.casanarestereo.screens.login

enum class Rol {
    USUARIO,
    EMISORA,
    ADMINISTRADOR
}