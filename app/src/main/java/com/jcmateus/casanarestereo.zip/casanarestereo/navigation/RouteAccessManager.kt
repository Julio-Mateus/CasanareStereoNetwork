package com.jcmateus.casanarestereo.navigation

import android.annotation.SuppressLint
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jcmateus.casanarestereo.HomeApplication
import com.jcmateus.casanarestereo.screens.formulario.PantallaFormulario
import com.jcmateus.casanarestereo.screens.home.Destinos
import com.jcmateus.casanarestereo.screens.login.AuthService
import com.jcmateus.casanarestereo.screens.login.LoginScreenViewModel
import com.jcmateus.casanarestereo.screens.login.LoginScreenViewModelFactory
import com.jcmateus.casanarestereo.screens.login.Rol

// Data class to represent route access with roles
data class RouteAccess(val route: String, val roles: List<Rol>)

object RouteAccessManager {

    // List of routes that should NOT show the Scaffold
    val excludedRoutes = listOf(
        Destinos.PantallaPresentacion.ruta,
        Destinos.CasanareLoginScreen.ruta,
        Destinos.SplashScreen.ruta,
        PantallaFormulario.SeleccionRol.ruta,
        PantallaFormulario.Estudiantes.ruta,
        PantallaFormulario.Estudiantes1.ruta,
        PantallaFormulario.Estudiantes2.ruta,
        PantallaFormulario.Estudiantes3.ruta,
        PantallaFormulario.Docentes.ruta,
        PantallaFormulario.PantallaFinal.ruta,
        Destinos.Pantalla16.ruta
    )

    // Definition of routes accessible by role
    val routeAccessList = listOf(
        // Routes for all roles
        RouteAccess(Destinos.Pantalla12.ruta, listOf(Rol.USUARIO, Rol.EMISORA, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Pantalla13.ruta, listOf(Rol.USUARIO, Rol.EMISORA, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.AcercaDe.ruta, listOf(Rol.USUARIO, Rol.EMISORA, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Notificaciones.ruta, listOf(Rol.USUARIO, Rol.EMISORA, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Privacidad.ruta, listOf(Rol.USUARIO, Rol.EMISORA, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Tema.ruta, listOf(Rol.USUARIO, Rol.EMISORA, Rol.ADMINISTRADOR)),
        // Routes exclusive to the "Emisora" role
        RouteAccess(Destinos.EmisoraVista.ruta, listOf(Rol.EMISORA, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.FormularioPerfilEmisora.ruta, listOf(Rol.EMISORA, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.FormularioNoticia.ruta, listOf(Rol.EMISORA, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.FormularioPodcast.ruta, listOf(Rol.EMISORA, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.FormularioPrograma.ruta, listOf(Rol.EMISORA, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.VistaNoticia().ruta, listOf(Rol.EMISORA, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.VistaPodcast().ruta, listOf(Rol.EMISORA, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.VistaPrograma.ruta, listOf(Rol.EMISORA, Rol.ADMINISTRADOR)),
        // Routes exclusive to the "Usuario" role
        RouteAccess(Destinos.Pantalla1.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Pantalla2.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Pantalla3.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Pantalla4.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Pantalla5.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Pantalla6.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Pantalla7.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Pantalla8.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Pantalla9.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Pantalla10.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Pantalla11.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.UsuarioPerfilScreen.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR)),
        RouteAccess(Destinos.Pantalla17.ruta, listOf(Rol.USUARIO, Rol.ADMINISTRADOR))
    )
    // Routes for the bottom navigation bar for "Usuario"
    val usuarioBottomBarRoutes = listOf(
        Destinos.Pantalla1.ruta,
        Destinos.Pantalla2.ruta,
        Destinos.Pantalla8.ruta
    )

    // Routes for the bottom navigation bar for "Emisora"
    val emisoraBottomBarRoutes = listOf(
        Destinos.VistaNoticia().ruta,
        Destinos.VistaPodcast().ruta,
        Destinos.VistaPrograma.ruta
    )

    // Function to determine if a route is accessible for a role
    fun isRouteAccessible(route: String, rol: Rol?): Boolean {
        if (excludedRoutes.contains(route)) return false
        if (rol == null) return false // If there is no role, no route is accessed
        return routeAccessList.any { it.route == route && it.roles.contains(rol) }
    }

    @SuppressLint("ViewModelConstructorInComposable")
    @Composable
    fun createLoginViewModel(application: HomeApplication): LoginScreenViewModel {
        val dataStoreManager = application.dataStoreManager
        val authService = AuthService(
            application.firebaseAuth,
            application.db,
            application.dataStoreManager
        ) // Create AuthService instance
        return viewModel(
            factory = LoginScreenViewModelFactory(
                dataStoreManager,
                authService, // Pass authService
                application.firebaseAuth // Pass firebaseAuth
            )
        )
    }
}