package com.jcmateus.casanarestereo.navigation


import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Scaffold
import androidx.compose.material.rememberScaffoldState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.jcmateus.casanarestereo.HomeApplication
import com.jcmateus.casanarestereo.PantallaPresentacion
import com.jcmateus.casanarestereo.SplashScreen
import com.jcmateus.casanarestereo.screens.formulario.Docentes
import com.jcmateus.casanarestereo.screens.formulario.Estudiantes
import com.jcmateus.casanarestereo.screens.formulario.Estudiantes1
import com.jcmateus.casanarestereo.screens.formulario.Estudiantes2
import com.jcmateus.casanarestereo.screens.formulario.Estudiantes3
import com.jcmateus.casanarestereo.screens.formulario.FormularioViewModel
import com.jcmateus.casanarestereo.screens.formulario.PantallaFinalScreen
import com.jcmateus.casanarestereo.screens.formulario.PantallaFormulario
import com.jcmateus.casanarestereo.screens.formulario.SeleccionRolScreen
import com.jcmateus.casanarestereo.screens.home.Destinos
import com.jcmateus.casanarestereo.screens.home.HomeViewModel
import com.jcmateus.casanarestereo.screens.home.NavegacionInferior
import com.jcmateus.casanarestereo.screens.home.TopBar
import com.jcmateus.casanarestereo.screens.home.currentRoute
import com.jcmateus.casanarestereo.screens.login.AuthService
import com.jcmateus.casanarestereo.screens.menus.Clasificados
import com.jcmateus.casanarestereo.screens.menus.configuracion.Configuraciones
import com.jcmateus.casanarestereo.screens.menus.Contactenos
import com.jcmateus.casanarestereo.screens.menus.Noticias_Internacionales
import com.jcmateus.casanarestereo.screens.menus.Noticias_Nacionales
import com.jcmateus.casanarestereo.screens.menus.Noticias_Regionales
import com.jcmateus.casanarestereo.screens.menus.Podcast
import com.jcmateus.casanarestereo.screens.menus.Programacion
import com.jcmateus.casanarestereo.screens.menus.Programas
import com.jcmateus.casanarestereo.screens.menus.Youtube_Casanare
import com.jcmateus.casanarestereo.screens.login.CasanareLoginScreen
import com.jcmateus.casanarestereo.screens.login.LoginScreenViewModel
import com.jcmateus.casanarestereo.screens.menus.CerrarSesionButton
import com.jcmateus.casanarestereo.screens.menus.Inicio
//import com.jcmateus.casanarestereo.InicioCasanareVista
//import com.jcmateus.casanarestereo.screens.menus.Educativo
import com.jcmateus.casanarestereo.screens.menus.Mi_Zona
import com.jcmateus.casanarestereo.screens.menus.Se_Le_Tiene
import com.jcmateus.casanarestereo.screens.menus.VideosYoutubeView
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.EmisoraViewModel
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.EmisoraVista
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.FormularioPerfilEmisora
import com.google.gson.Gson
import com.jcmateus.casanarestereo.SplashScreenDestination
import com.jcmateus.casanarestereo.screens.home.Drawer
import com.jcmateus.casanarestereo.screens.home.ScaffoldWithNavigation
import com.jcmateus.casanarestereo.screens.home.shouldShowBottomBar
import com.jcmateus.casanarestereo.screens.home.shouldShowDrawer
import com.jcmateus.casanarestereo.screens.home.shouldShowTopBar
import com.jcmateus.casanarestereo.screens.login.DataStoreManager
import com.jcmateus.casanarestereo.screens.login.Rol
import com.jcmateus.casanarestereo.screens.menus.configuracion.PantallaAcercaDe
import com.jcmateus.casanarestereo.screens.menus.configuracion.PantallaNotificaciones
import com.jcmateus.casanarestereo.screens.menus.configuracion.PantallaPrivacidad
import com.jcmateus.casanarestereo.screens.menus.configuracion.PantallaTema
import com.jcmateus.casanarestereo.screens.menus.emisoras.EmisorasScreen
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.EmisoraRepository
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.contenido.Contenido
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.noticias.FormularioNoticia
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.noticias.VistaNoticia
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.noticias.VistaNoticiaScreen
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.podcast.FormularioPodcast
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.podcast.PodcastRepository
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.podcast.PodcastViewModel
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.podcast.PodcastViewModelFactory
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.podcast.VistaPodcast
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.programacion.FormularioPrograma
import com.jcmateus.casanarestereo.screens.usuarios.usuario.UsuarioPerfilScreen
import com.jcmateus.casanarestereo.screens.usuarios.usuario.UsuarioPerfilViewModel
import com.jcmateus.casanarestereo.screens.usuarios.usuario.UsuarioPerfilViewModelFactory
import com.jcmateus.casanarestereo.screens.usuarios.usuario.UsuarioRepository
import com.jcmateus.casanarestereo.screens.usuarios.usuario.UsuarioViewModel
import kotlin.text.contains


@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun NavigationHost(
    navController: NavHostController,
    innerPadding: PaddingValues,
    loginViewModel: LoginScreenViewModel,
    formularioViewModel: FormularioViewModel,
    authService: AuthService,
    emisoraViewModel: EmisoraViewModel,
    podcastViewModel: PodcastViewModel,
    usuarioViewModel: UsuarioViewModel,
    dataStoreManager: DataStoreManager,
    emisoraRepository: EmisoraRepository,
    usuarioRepository: UsuarioRepository,
    firebaseFirestore: FirebaseFirestore,
    firebaseStorage: FirebaseStorage
) {
    Log.d("NavController", "NavigationHost: $navController")

    // Estado local para el rol
    var localUserRol by remember { mutableStateOf<Rol?>(null) }
    // Obtiene el rol del usuario actual desde el DataStore. Si no hay rol, se asigna null.
    val userRol by dataStoreManager.getRol().collectAsState(initial = null)
    // Leer el rol dentro de un LaunchedEffect
    LaunchedEffect(key1 = userRol) {
        if (userRol != null) {
            localUserRol = userRol
        }
    }

    val currentNavBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = currentNavBackStackEntry?.destination?.route ?: ""

    LaunchedEffect(key1 = Unit) {
        SplashScreenDestination.destination.collect { destination ->
            Log.d("NavigationHost", "Navegando a: $destination")
            navController.navigate(destination)
        }
    }

    NavHost(
        navController = navController,
        startDestination = Destinos.SplashScreen.ruta,
        modifier = Modifier.padding(paddingValues = innerPadding)
    ) {
        // Rutas sin Scaffold
        composable(Destinos.SplashScreen.ruta) {
            SplashScreen(
                authService = authService,
                dataStoreManager = dataStoreManager,
                emisoraRepository = emisoraRepository
            )
        }
        composable(Destinos.PantallaPresentacion.ruta) {
            PantallaPresentacion(navController = navController, loginViewModel = loginViewModel)
        }
        composable(Destinos.CasanareLoginScreen.ruta) {
            val emisoraViewModelFactory =
                (LocalContext.current.applicationContext as HomeApplication).emisoraViewModelFactory
            val emisoraViewModel: EmisoraViewModel = viewModel(factory = emisoraViewModelFactory)
            CasanareLoginScreen(
                navController = navController,
                emisoraViewModel = emisoraViewModel,
                loginViewModel = loginViewModel
            )
        }
        // Rutas del formulario
        composable(PantallaFormulario.SeleccionRol.ruta) {
            SeleccionRolScreen(navController)
        }
        composable(PantallaFormulario.Estudiantes.ruta) {
            Estudiantes(formularioViewModel, navController)
        }
        composable(PantallaFormulario.Estudiantes1.ruta) {
            Estudiantes1(formularioViewModel, navController)
        }
        composable(PantallaFormulario.Estudiantes2.ruta) {
            Estudiantes2(formularioViewModel, navController)
        }
        composable(PantallaFormulario.Estudiantes3.ruta) {
            Estudiantes3(formularioViewModel, navController)
        }
        composable(PantallaFormulario.Docentes.ruta) {
            Docentes(formularioViewModel, navController)
        }
        composable(PantallaFormulario.PantallaFinal.ruta) {
            // Creamos la instancia del ViewModel directamente aquí
            val formularioViewModel: FormularioViewModel = viewModel()
            PantallaFinalScreen(formularioViewModel, navController)
        }
        // Rutas con Scaffold
        composable(Destinos.Pantalla1.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Inicio(navController, innerPadding)
            }
        }
        composable(Destinos.Pantalla2.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Mi_Zona(navController, innerPadding)
            }
        }
        composable(Destinos.Pantalla3.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Noticias_Regionales(innerPadding, navController)
            }
        }
        composable(Destinos.Pantalla4.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Noticias_Nacionales(navController, innerPadding)
            }
        }
        composable(Destinos.Pantalla5.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Noticias_Internacionales(navController, innerPadding)
            }
        }
        composable(Destinos.Pantalla6.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Clasificados(navController, innerPadding)
            }
        }
        composable(Destinos.Pantalla7.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Se_Le_Tiene(navController, innerPadding)
            }
        }
        composable(Destinos.Pantalla8.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Programacion(navController, innerPadding)
            }
        }
        composable(Destinos.Pantalla9.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Programas(navController, innerPadding)
            }
        }
        composable(Destinos.Pantalla10.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Podcast(innerPadding, navController)
            }
        }
        composable(Destinos.Pantalla11.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                VideosYoutubeView(navController, innerPadding)
            }
        }
        composable(Destinos.Pantalla12.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Configuraciones(innerPadding, navController)
            }
        }
        composable(Destinos.Pantalla13.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Contactenos(innerPadding, navController)
            }
        }
        composable(Destinos.Pantalla17.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                Youtube_Casanare(navController, innerPadding)
            }
        }
        composable(Destinos.AcercaDe.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                PantallaAcercaDe(innerPadding, navController)
            }
        }
        composable(Destinos.Notificaciones.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                PantallaNotificaciones(innerPadding, navController)
            }
        }
        composable(Destinos.Privacidad.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                PantallaPrivacidad(innerPadding, navController)
            }
        }
        composable(Destinos.Tema.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                PantallaTema(innerPadding, navController)
            }
        }
        composable(Destinos.EmisoraVista.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                EmisoraVista(navController, emisoraViewModel, innerPadding)
            }
        }
        composable(Destinos.FormularioPerfilEmisora.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                FormularioPerfilEmisora(navController, authService, innerPadding)
            }
        }
        composable(Destinos.FormularioNoticia.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                FormularioNoticia(innerPadding, navController)
            }
        }
        composable(Destinos.FormularioPodcast.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                FormularioPodcast(innerPadding, podcastViewModel, navController)
            }
        }
        composable(Destinos.FormularioPrograma.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                FormularioPrograma(innerPadding, navController)
            }
        }
        composable(Destinos.VistaNoticia().ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                VistaNoticia(innerPadding.toString(), innerPadding, navController)
            }
        }
        composable(Destinos.VistaPodcast().ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                VistaPodcast(firebaseFirestore, firebaseStorage)
            }
        }
        composable(Destinos.VistaPrograma.ruta) {
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                //VistaPrograma(navController, innerPadding, emisoraViewModel, firebaseFirestore, firebaseStorage)
            }
        }
        composable(
            route = "${Destinos.UsuarioPerfilScreen.ruta}/{uid}",
            arguments = listOf(navArgument("uid") { type = NavType.StringType })
        ) { backStackEntry ->
            val uid = backStackEntry.arguments?.getString("uid") ?: ""
            ScaffoldWithNavigation(
                localUserRol,
                currentRoute,
                navController,
                dataStoreManager,
                authService
            ) { innerPadding ->
                val context = LocalContext.current
                val usuarioPerfilViewModelFactory =
                    (context.applicationContext as HomeApplication).usuarioPerfilViewModelFactory
                val usuarioPerfilViewModel: UsuarioPerfilViewModel =
                    viewModel(factory = usuarioPerfilViewModelFactory)
                UsuarioPerfilScreen(usuarioPerfilViewModel, navController, uid, innerPadding)
            }
        }
    }
}


