package com.jcmateus.casanarestereo

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.core.DataStore
import androidx.datastore.dataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.navigation.NavHostController
import androidx.navigation.compose.ComposeNavigator
import androidx.navigation.compose.DialogNavigator
import com.google.firebase.appcheck.BuildConfig
import com.google.firebase.appcheck.FirebaseAppCheck
import com.jcmateus.casanarestereo.screens.login.AuthService
import com.jcmateus.casanarestereo.screens.login.DataStoreManager
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.EmisoraRepository
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.EmisoraViewModel
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.EmisoraViewModelFactory
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.noticias.NoticiaRepository
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.noticias.NoticiaViewModelFactory
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.podcast.PodcastRepository
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.podcast.PodcastViewModel
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.podcast.PodcastViewModelFactory
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.programacion.ProgramaRepository
import com.jcmateus.casanarestereo.screens.usuarios.emisoras.programacion.ProgramaViewModelFactory
import com.jcmateus.casanarestereo.screens.usuarios.usuario.UsuarioPerfilViewModel
import com.jcmateus.casanarestereo.screens.usuarios.usuario.UsuarioRepository
import com.jcmateus.casanarestereo.screens.usuarios.usuario.UsuarioViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.jcmateus.casanarestereo.screens.usuarios.usuario.UsuarioPerfilViewModelFactory
import com.jcmateus.casanarestereo.screens.usuarios.usuario.UsuarioViewModelFactory

// Define the DataStore as a top-level extension function
val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")
class HomeApplication : Application() {
    val navController: NavHostController by lazy {
        Log.d("HomeApplication", "navController: Iniciando creación de NavHostController")
        NavHostController(this).apply {
            navigatorProvider.addNavigator(ComposeNavigator())
            navigatorProvider.addNavigator(DialogNavigator())
            setViewModelStore(ViewModelStore())
        }.also {
            Log.d("HomeApplication", "navController: Instancia de NavHostController creada")
        }
    }

    val firebaseAuth: FirebaseAuth by lazy {
        Log.d("HomeApplication", "firebaseAuth: Iniciando creación de FirebaseAuth")
        FirebaseAuth.getInstance().also {
            Log.d("HomeApplication", "firebaseAuth: Instancia de FirebaseAuth creada")
        }
    }
    var showScaffold by mutableStateOf(false)

    val dataStoreManager: DataStoreManager by lazy {
        Log.d("HomeApplication", "dataStoreManager: Iniciando creación de DataStoreManager")
        DataStoreManager(this).also {
            Log.d("HomeApplication", "dataStoreManager: Instancia de DataStoreManager creada")
        }
    }
    val db: FirebaseFirestore by lazy {
        Log.d("HomeApplication", "db: Iniciando creación de FirebaseFirestore")
        FirebaseFirestore.getInstance().also {
            Log.d("HomeApplication", "db: Instancia de FirebaseFirestore creada")
        }
    }
    val storage: FirebaseStorage by lazy {
        Log.d("HomeApplication", "storage: Iniciando creación de FirebaseStorage")
        FirebaseStorage.getInstance().also {
            Log.d("HomeApplication", "storage: Instancia de FirebaseStorage creada")
        }
    }
    val authService: AuthService by lazy {
        Log.d("HomeApplication", "authService: Iniciando creación de AuthService")
        AuthService(firebaseAuth, db, dataStoreManager).also {
            Log.d("HomeApplication", "authService: Instancia de AuthService creada")
        }
    }
    val emisoraRepository: EmisoraRepository by lazy {
        Log.d("HomeApplication", "emisoraRepository: Iniciando creación de EmisoraRepository")
        EmisoraRepository(db, storage).also {
            Log.d("HomeApplication", "emisoraRepository: Instancia de EmisoraRepository creada")
        }
    }
    val emisoraViewModelFactory: EmisoraViewModelFactory by lazy {
        Log.d("HomeApplication", "emisoraViewModelFactory: Iniciando creación de EmisoraViewModelFactory")
        EmisoraViewModelFactory(emisoraRepository, firebaseAuth, db).also {
            Log.d("HomeApplication", "emisoraViewModelFactory: Instancia de EmisoraViewModelFactory creada")
        }
    }

    val programaRepository: ProgramaRepository by lazy {
        Log.d("HomeApplication", "programaRepository: Iniciando creación de ProgramaRepository")
        ProgramaRepository(db).also {
            Log.d("HomeApplication", "programaRepository: Instancia de ProgramaRepository creada")
        }
    }
    val programaViewModelFactory: ProgramaViewModelFactory by lazy {
        Log.d("HomeApplication", "programaViewModelFactory: Iniciando creación de ProgramaViewModelFactory")
        ProgramaViewModelFactory(programaRepository, firebaseAuth, db).also {
            Log.d("HomeApplication", "programaViewModelFactory: Instancia de ProgramaViewModelFactory creada")
        }
    }

    val noticiaRepository: NoticiaRepository by lazy {
        Log.d("HomeApplication", "noticiaRepository: Iniciando creación de NoticiaRepository")
        NoticiaRepository(db).also {
            Log.d("HomeApplication", "noticiaRepository: Instancia de NoticiaRepository creada")
        }
    }
    val noticiaViewModelFactory: NoticiaViewModelFactory by lazy {
        Log.d("HomeApplication", "noticiaViewModelFactory: Iniciando creación de NoticiaViewModelFactory")
        NoticiaViewModelFactory(noticiaRepository, firebaseAuth, db, storage, authService, dataStoreManager).also {
            Log.d("HomeApplication", "noticiaViewModelFactory: Instancia de NoticiaViewModelFactory creada")
        }
    }

    val emisoraViewModel: EmisoraViewModel by lazy {
        Log.d("HomeApplication", "emisoraViewModel: Iniciando creación de EmisoraViewModel")
        emisoraViewModelFactory.create(EmisoraViewModel::class.java).also {
            Log.d("HomeApplication", "emisoraViewModel: Instancia de EmisoraViewModel creada")
        }
    }
    val podcastViewModel: PodcastViewModel by lazy {
        Log.d("HomeApplication", "podcastViewModel: Iniciando creación de PodcastViewModel")
        podcastViewModelFactory.create(PodcastViewModel::class.java).also {
            Log.d("HomeApplication", "podcastViewModel: Instancia de PodcastViewModel creada")
        }
    }

    val podcastRepository: PodcastRepository by lazy {
        Log.d("HomeApplication", "podcastRepository: Iniciando creación de PodcastRepository")
        PodcastRepository(db).also {
            Log.d("HomeApplication", "podcastRepository: Instancia de PodcastRepository creada")
        }
    }
    val podcastViewModelFactory by lazy {
        Log.d("HomeApplication", "podcastViewModelFactory: Iniciando creación de PodcastViewModelFactory")
        PodcastViewModelFactory(
            podcastRepository,
            db
        ).also {
            Log.d("HomeApplication", "podcastViewModelFactory: Instancia de PodcastViewModelFactory creada")
        }
    }

    val usuarioRepository: UsuarioRepository by lazy {
        Log.d("HomeApplication", "usuarioRepository: Iniciando creación de UsuarioRepository")
        UsuarioRepository(db, firebaseAuth).also {
            Log.d("HomeApplication", "usuarioRepository: Instancia de UsuarioRepository creada")
        }
    }

    val usuarioViewModelFactory: UsuarioViewModelFactory by lazy {
        Log.d("HomeApplication", "usuarioViewModelFactory: Iniciando creación de UsuarioViewModelFactory")
        UsuarioViewModelFactory(usuarioRepository).also {
            Log.d("HomeApplication", "usuarioViewModelFactory: Instancia de UsuarioViewModelFactory creada")
        }
    }
    val usuarioPerfilViewModelFactory: UsuarioPerfilViewModelFactory by lazy {
        Log.d("HomeApplication", "usuarioPerfilViewModelFactory: Iniciando creación de UsuarioPerfilViewModelFactory")
        UsuarioPerfilViewModelFactory(usuarioRepository, authService, db, storage).also {
            Log.d("HomeApplication", "usuarioPerfilViewModelFactory: Instancia de UsuarioPerfilViewModelFactory creada")
        }
    }

    val usuarioViewModel: UsuarioViewModel by lazy {
        Log.d("HomeApplication", "usuarioViewModel: Iniciando creación de UsuarioViewModel")
        usuarioViewModelFactory.create(UsuarioViewModel::class.java).also {
            Log.d("HomeApplication", "usuarioViewModel: Instancia de UsuarioViewModel creada")
        }
    }

    val usuarioPerfilViewModel: UsuarioPerfilViewModel by lazy {
        Log.d("HomeApplication", "usuarioPerfilViewModel: Iniciando creación de UsuarioPerfilViewModel")
        usuarioPerfilViewModelFactory.create(UsuarioPerfilViewModel::class.java).also {
            Log.d("HomeApplication", "usuarioPerfilViewModel: Instancia de UsuarioPerfilViewModel creada")
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.d("HomeApplication", "onCreate: HomeApplication creado")
    }
}